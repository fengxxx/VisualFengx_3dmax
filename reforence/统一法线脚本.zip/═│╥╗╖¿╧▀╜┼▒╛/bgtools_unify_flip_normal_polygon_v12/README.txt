/* 
*****************************************************************
Macro Scripts for Modeling Stuff ( tested in max 2009 - 2010 ) 
Unify/Flip normal polygon V 1.2 
Last update ( 2010 -10-29)

Author: Budi Gunawan (Oct 2010)
hellocomred@gmail.com

Modify at your own risk
Feel free & Enjoy 
*****************************************************************
*/


A script assist to make normal polygons of the objects.


3 options for using this tool:

- Unify or flips all the faces of multiple selected objects with/without accses to SubObjects level.

- Unify or flips multiple selected faces of a single object with accses to SubObjects level.

- Auto Select the faces for distinguishing Normal or Unnormal Faces of a single object with/without accses to SubObjects level.


History:
Unify/Flip normal polygon V 1.0
- Main idea the Tools

Update : 
Unify/Flip normal polygon V 1.2
- Changing and Optimizing a few code.
- Added support: multiple selected faces of one object with accses to SubObjects level.
- Added a switcher UI buttons to Auto detect/Select faces.
- Added support: Auto Select the faces for distinguishing Normal or Unnormal Faces of Single object.
- Convert the code from .mcr to .mse file.



Additional Info: 

working on the baseObject editable_mesh and editable_poly.

Tips : Collapse the stack of modifiers objects first before using this scripts


Install :
1. for .mcr file :
- Copy "BGtools_Unify_Flip_normal_polygon.mcr" into your \ui\usermacros.. max directory.
  ie: C:\Documents and Settings\USER\Local Settings\Application Data\Autodesk\3dsmax\2009 - 32bit\enu\UI\usermacros\
  ( If you know it, you can uninstall later by deleting the file/replacing a new version file.)
  Restart Max and you will find it under Customize >> CustomizeUserinterface, Category 'BG tools'.

- Or go to MAXScript>>Run Script... and select the "BGtools_Unify_Flip_normal_polygon.mcr" file,
  then find it under Customize>>CustomizeUserinterface, Category 'BG tools'

- Click 'Make unify or flip normal...' and then Assign into keyboard, toolbars, Quads or menus.
  the button name is 'Face normal'

2. for .mse file :
- Put 'BG-Unify_Flip_normal.mse' into "scripts/BG_Script" folder


Version Requirement: tested in max 2009 - 2010


